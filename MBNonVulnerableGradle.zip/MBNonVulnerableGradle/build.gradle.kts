plugins {
    id("java")
}

group = "org.example"
version = "1.0-SNAPSHOT"

repositories {
    mavenCentral()
}

dependencies {
    testImplementation("com.thoughtworks.xstream:xstream:1.4.20")
    testImplementation("org.elasticsearch:elasticsearch:8.11.4")
    testImplementation("com.liferay.portal:release.portal.bom:7.4.3.67")
    testImplementation("io.undertow:undertow-core:2.2.27.Final")
    testImplementation("org.apache.tomcat.embed:tomcat-embed-core:11.0.0-M15")
    testImplementation("org.keycloak:keycloak-parent:21.1.2")
    testImplementation("org.springframework:spring-core:6.1.2")
    testImplementation("org.apache.nifi:nifi:1.16.2")
    testImplementation("org.eclipse.jetty:jetty-server:9.4.51.v20230217")
    testImplementation("org.springframework.security:spring-security-core:6.0.2")
    testImplementation("org.keycloak:keycloak-services:23.0.4")
    testImplementation("org.bouncycastle:bcprov-jdk14:1.74")
    testImplementation("org.apache.activemq:activemq-client:5.18.3")
    testImplementation("org.apache.dubbo:dubbo:3.1.5")
    testImplementation("org.apache.jspwiki:jspwiki-main:2.12.0")
    testImplementation("org.apache.cxf:cxf:3.4.10")
    testImplementation("org.apache.hadoop:hadoop-main:3.3.5")
    testImplementation("org.apache.hadoop:hadoop-common:3.3.4")
    testImplementation("org.apache.jspwiki:jspwiki-war:2.12.0")
    testImplementation("org.apache.ranger:ranger:2.4.0")
    testImplementation("com.vaadin:flow-server:24.3.2")
    testImplementation("com.vaadin:vaadin-bom:22.1.0")
    testImplementation("org.apache.camel:camel-core:3.14.9")
    testImplementation("org.apache.cxf:cxf-core:3.4.10")
    testImplementation("org.apache.struts.xwork:xwork-core:2.3.37")
    testImplementation("com.jfinal:jfinal:5.1.3")
    testImplementation("net.mingsoft:ms-mcms:5.3.5")
    testImplementation("com.fasterxml.jackson.core:jackson-databind:2.14.3")
    testImplementation("org.apache.struts:struts2-core:6.3.0.2")
    testImplementation("org.keycloak:keycloak-core:23.0.3")
    testImplementation("org.apache.inlong:manager-pojo:1.10.0")
    testImplementation("org.apache.tika:tika-core:2.8.0")
    testImplementation("io.netty:netty:3.10.5.Final")

}

tasks.test {
    useJUnitPlatform()
}
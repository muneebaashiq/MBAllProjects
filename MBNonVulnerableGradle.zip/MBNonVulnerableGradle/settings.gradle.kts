rootProject.name = "MBNonVulnerableGradle"

